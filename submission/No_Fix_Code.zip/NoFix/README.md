# No Fix analysis code

Extract this folder and run the commands below from its root. The original distribution and recovered files are included for offline analysis. The report and presentation binaries are separate submission files.

## Run the analysis

We used Python 3.12. From this repository's root:

```sh
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python src/analyze.py
python src/check_gcode.py
python src/preview_cad.py
python src/build_report.py
```

The original distribution is in `inputs/`, so the geometry analysis and ZIP extraction work offline after installing the dependencies. The recovered remote files are already in `recovered/`; the scripts do not need an account, token, or live link. Source URLs remain in the registry for verification. OpenCascade's STEP import converts the inch-based source assembly to millimeters.

`analyze.py` is specific to this supplied assembly. Its solid numbers and sampling coordinates are documented in the code. We manually transcribed the inscriptions into `results/transcribed_clues.json`; the code exports evidence views, then checks the pattern arithmetic and archive extraction. It does not claim to be a general OCR or STEP parser.

To rebuild the source PDF image used in the report, install Poppler and run:

```sh
pdftoppm -scale-to 2000 -png 'recovered/Pawn Exploded View.pdf' 'evidence/pawn_exploded'
```

The presentation source is [build_deck.mjs](presentation/build_deck.mjs). It uses the Artifact Tool runtime bundled with Codex. The exported PPTX is included for normal PowerPoint use; Python is only needed for the analysis and PDF report.

## What the checks establish

We verified the board decodes, ZIP CRCs, recovered STEP imports, and exact source hashes. We inspected G-code without sending it to hardware. The Knight file has only 78 numbered layers against 177 in its header and includes two non-G-code lines. Its original STEP is the recovery route. The King file has shutdown commands and reaches the header's maximum Z, with a one-layer header mismatch (337 declared versus 336 marked).

The inscriptions, target dimensions, prototype CAD, and filament G-code are separate evidence. The King inscription mentions metal production, but its linked commands describe filament extrusion. We did not test a metal build, validate hardware fits, or manufacture a finished set. We preserved the recovered files without repairing or rescaling them.

## Sources

The three original files come from the challenge distribution. The exploded pawn drawing credits Works by Design. The recovered remote manufacturing files come from the links embedded in that distribution. The material source is the [official EOS datasheet](https://www.eos.info/var/assets/03_system-related-assets/material-related-contents/metal-materials-and-examples/metal-material-datasheet/aluminium/material_datasheet_eos_aluminium_alf357_premium_en.pdf); we link to it instead of republishing the complete third-party PDF. No AI-generated image is used as experimental or CAD evidence.
