# No Fix submission

The submission folder contains the report PDF, code ZIP, and supporting ZIP.

The presentation folder contains the PDF, also included in the supporting ZIP. All five recovered manufacturing files are in the code ZIP.
